#pragma once

#include <chrono>
#include <condition_variable>
#include <cstdio>
#include <functional>
#include <future>
#include <mutex>
#include <queue>
#include <thread>
#include <vector>

class ThreadPool {
 public:
  ThreadPool(size_t num_threads);
  ~ThreadPool();

  // Enqueue a job.
  template <class F, class... Args>
  std::future<typename std::result_of<F(Args...)>::type> EnqueueJob(
    F&& f, Args&&... args);

 private:
  // Total number of worker threads.
  size_t num_threads_;
  // a vector for worker threads.
  std::vector<std::thread> worker_threads_;
  // a queue for storing jobs.
  std::queue<std::function<void()>> jobs_;
  // a condition variable and a mutex lock used in enqueuing jobs.
  std::condition_variable cv_job_q_;
  std::mutex m_job_q_;

  // stop all worker threads.
  bool stop_all;
  void WorkerThread();
};

template <class F, class... Args>
std::future<typename std::result_of<F(Args...)>::type> ThreadPool::EnqueueJob(
  F&& f, Args&&... args) {
  if (stop_all) {
    throw std::runtime_error("ThreadPool 사용 중지됨");
  }

  // First, get the return_type of the function.
  using return_type = typename std::result_of<F(Args...)>::type;

  /*
  Second, Assign f into job variable
    - By using packaged_task, we can get a return value of an asynchronous function.
    - Bound args to the f using bind.
    - Used shared_ptr to prevent destroying job variable after finishing EnqueueJob function and to make it easy to destroy when there is no reference to that job variable.
    - To remove unnecessary copies, used perfect forwarding by forward
  */
  auto job = std::make_shared<std::packaged_task<return_type()>>(
    std::bind(std::forward<F>(f), std::forward<Args>(args)...));

  // Third, get a future from the given job.
  std::future<return_type> job_result_future = job->get_future();
  {
    // Fourth, push it to the jobs_ queue with a lock.
    std::lock_guard<std::mutex> lock(m_job_q_);
    jobs_.push([job]() { (*job)(); });
  }

  // Fifth, notify a random thread and return the future.
  cv_job_q_.notify_one();
  return job_result_future;
}

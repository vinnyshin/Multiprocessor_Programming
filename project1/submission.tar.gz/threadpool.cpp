#include <threadpool.hpp>

/*
Reserve the space of the vector for the threads and make worker threads using a lambda function.
*/
ThreadPool::ThreadPool(size_t num_threads)
    : num_threads_(num_threads), stop_all(false) {
  worker_threads_.reserve(num_threads_);
  for (size_t i = 0; i < num_threads_; ++i) {
    worker_threads_.emplace_back([this]() { this->WorkerThread(); });
  }
}

/*
By making the stop_all variable true, wake up all the worker threads so that they can exit normally.
The master thread will wait by calling join function until every exit is done.
*/
ThreadPool::~ThreadPool() {
  stop_all = true;
  cv_job_q_.notify_all();

  for (auto& t : worker_threads_) {
    t.join();
  }
}

void ThreadPool::WorkerThread() {
  while (true) {
    // First, get the m_job_q_ mutex lock.
    std::unique_lock<std::mutex> lock(m_job_q_);
    
    /*
    Second, call the wait function.
      - if the jobs_ is not empty or stop_all is set true, return wait call right away.
      - (cont'd) if stop_all was set true return the Workerthread function.
    */
    cv_job_q_.wait(lock, [this]() { return !this->jobs_.empty() || stop_all; });
    if (stop_all && this->jobs_.empty()) {
      return;
    }

    // Third, dequeue the job from the jobs_ queue and do the job.
    std::function<void()> job = std::move(jobs_.front());
    jobs_.pop();
    lock.unlock();

    // Fourth, return to the step "First".
    job();
  }
}

#include <iostream>
#include "Joiner.hpp"
#include "Parser.hpp"
#include "threadpool.hpp"

using namespace std;

// //---------------------------------------------------------------------------
extern ThreadPool tp;

// Job wrapper for the worker thread.
string work(string& query, Joiner* joiner) {
  QueryInfo q;
  q.parseQuery(query);
  return (*joiner).join(q);
}

int main(int argc, char* argv[]) {
   Joiner joiner;
   // Read join relations
   
   string line;
   while (getline(cin, line)) {
      if (line == "Done") break;
      joiner.addRelation(line.c_str());
   }
   // Preparation phase (not timed)
   // Build histograms, indexes,...
   //
   
   vector<string> queries;
   vector<future<string>> results;

   queries.reserve(40);
   results.reserve(40);

   while (getline(cin, line)) {
      if (line == "F")  {

         // Second, assign a job to each thread.
         for (string& query : queries) {
            results.emplace_back(tp.EnqueueJob(work, query, &joiner));
         }
         
         // Third, Wait for the execution.
         for (auto& f : results) {
            cout << f.get();
         }
         
         results.clear();
         queries.clear();
         continue; // End of a batch 
      }
      
      // First, get the queries from the batch.
      queries.emplace_back(line);
   }
   return 0;
}

// #include <iostream>
// #include "Joiner.hpp"
// #include "Parser.hpp"
// #include "threadpool.cpp"

// using namespace std;
// //---------------------------------------------------------------------------
// constexpr int NUM_THREADS = 40;

// string work(string& query, Joiner* joiner) {
//   QueryInfo q;
//   q.parseQuery(query);
//   return (*joiner).join(q);
// }

// int main(int argc, char* argv[]) {
//    ThreadPool tp(NUM_THREADS);

//    Joiner joiner;
//    // Read join relations
//    string line;
//    freopen("./workloads/small/small_freopen.init", "r", stdin);
//    while (getline(cin, line)) {
//       if (line == "Done") break;
//       joiner.addRelation(line.c_str());
//    }
//    // Preparation phase (not timed)
//    // Build histograms, indexes,...
//    //
   
//    vector<string> queries;
//    vector<future<string>> results;

//    queries.reserve(40);
//    results.reserve(40);

//    QueryInfo i;
   
//    freopen("./workloads/small/small.work", "r", stdin);
   
//    while (getline(cin, line)) {
//       if (line == "F")  {
//          for (string& query : queries) {
//             results.emplace_back(tp.EnqueueJob(work, query, &joiner));
//          }
         
//          for (auto& f : results) {
//             cout << f.get();
//          }
         
//          queries.clear();
//          results.clear();
//          continue; // End of a batch 
//       }

//       queries.emplace_back(line);
//    }
//    return 0;
// }

#pragma once

// Empty placeholders for compatibility
#define INDEX_LOG_TRACE(...) ((void)0)
#define INDEX_LOG_DEBUG(...) ((void)0)
#define INDEX_LOG_INFO(...) ((void)0)
#define INDEX_LOG_WARN(...) ((void)0)
#define INDEX_LOG_ERROR(...) ((void)0)
